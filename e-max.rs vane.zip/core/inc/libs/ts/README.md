# ts3admin.class
The ts3admin.class is a powerful api for communication with Teamspeak 3 Servers from your website! Your creativity knows no bounds!

ts3admin.class.php written by Stefan 'par0noid' Zehnpfennig

You can use this software under the terms of the GNU General Public License v3.

Dev-Website: http://ts3admin.info

http://par0noid.info
