<?php
include($_SERVER['DOCUMENT_ROOT']."/konfiguracija.php");
?>
