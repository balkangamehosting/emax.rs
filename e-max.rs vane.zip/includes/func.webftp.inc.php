<?php


class Fajlovi
{
	public function fajlovi_lista($serverid,$dir,$tpl_browse=false)
	{
	
	}
}
?>