<?php
	/**
	 * Class written by xPaw
	 *
	 * Website: http://xpaw.me
	 * GitHub: https://github.com/xPaw/PHP-Source-Query-Class
	 */
	
	class SourceQueryException extends Exception
	{
		// Exception thrown by SourceQuery class
	}
