<?php

include('includes.php');

//$gtapi->GraficonInBanner();

//echo $gtapi->gt_platyer();

echo $gtapi->GTBigGraficonPlayer();
//echo $gtapi->GetServerHostedMap();
//echo $gtapi->GetCurrentMapImage();

?>
