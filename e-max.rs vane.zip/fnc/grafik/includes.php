<?php

require_once('classes/gtapi.php');

$gtapi = new kevia_gt_api('176.57.188.35', '27022');

?>