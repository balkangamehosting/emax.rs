<?php

include('../includes.php');
include('phplot.php');

echo $gtapi->GTSmallForBanner();

?>