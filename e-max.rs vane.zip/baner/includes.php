<?php

require_once('classes/gtapi.php');

$gtapi = new GTApi($ipAdr, $ipPor);

?>