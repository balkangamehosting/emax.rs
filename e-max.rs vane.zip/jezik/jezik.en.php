<?php  

/* 
------------------
Language: Engleski
------------------
*/

$jezik = array(); 

$jezik['1'] = "Hello :D";


$jezik['uplata'] 			= "How to pay by SMS?";
$jezik['obv1'] 				= "Questions and suggestions regarding SMS Service write to: <span style='color:red;'>info@e-game.me</span>.";
$jezik['obv2'] 				= "2). SMS payment provided Fortumo.com.";
$jezik['obv3'] 				= "3). Choose which country you are sending a text message.";
$jezik['obv4'] 				= "4). <span style='color:red;'>NOTE!</span> After sending SMS, it can happen sometimes that the money is not paid to your account for several hours due to the delay between Fortum and mobile providers!";
$jezik['drzave'] 			= "A list of countries that support fortumo:";
$jezik['upustvo'] 			= "Instructions for SMS Payment!";
$jezik['primer']			= "Example:";
$jezik['info'] 				= "Info:";
$jezik['drzava'] 			= "Country:";
$jezik['pare'] 				= "Price:";
$jezik['kod'] 				= "Type:";
$jezik['send']				= "Send to number:";
$jezik['supp']				= "Support:";
$jezik[' Pocetna']			= " Home";
$jezik[' Game Panel']		= " Game Panel";
$jezik[' Korisnicki Panel']		= " User Panel";
$jezik[' Naruci']			= " Buy";
$jezik[' Cenovnik']			= " Price List";
$jezik[' Kontakt']			= " Contact";
$jezik['GameTracker']		= "GameTracker";
$jezik['VESTI']				= "NEWS";
$jezik['DEMO']				= "DEMO";
$jezik[' LOGIN']				= " LOGIN";
$jezik[' REGISTRUJ SE']		= " REGISTER";
$jezik[' MOJ PROFIL']		= " MY PROFILE";
$jezik['EDIT']				= "EDIT";
$jezik['BILLING']			= "BILLING";
$jezik['LOGOUT']			= "LOGOUT";
$jezik['PREUZMITE NAJBOLJI COUNTER STRIKE 1.6']	= "DOWNLOAD THE BEST CS 1.6";
$jezik['DOWNLOAD NOW!']		= "DOWNLOAD NOW!";
$jezik['Igra:']				= "Game:";
$jezik['USKORO!']			= "SOON!";
$jezik['Vise Info']			= "More Info";
$jezik[' Naruci']			= " Buy";
?>