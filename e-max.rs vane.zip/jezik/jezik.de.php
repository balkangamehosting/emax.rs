<?php 

/* 
------------------
Language: Serbian
------------------
*/

$jezik = array(); 

$jezik['1'] = "Cao :D";

$jezik['uplata'] 			= "Kako uplatiti pomoću SMS-a?";
$jezik['obv1'] 				= "1). Pitanja i sugestije vezane za SMS Servis pišite na: <span style='color:red;'>info@e-game.me</span>.";
$jezik['obv2'] 				= "2). SMS naplatu obezbijedio Fortumo.com.";
$jezik['obv3'] 				= "3). Izaberite državu iz koje šaljete SMS poruku.";
$jezik['obv4'] 				= "4). <span style='color:red;'>NAPOMENA!</span> Posle slanja SMS-a, može se desiti nekad da novac ne legne na vas nalog i po nekoliko sati zbog zakašnjenja između Fortuma i mobilnih provajdera! 
<br /> - U slučaju da vaš zatekne ovo, javite se na email: info@e-game.me ili blejab@gmail.com.!";
$jezik['drzave'] 			= "Lista drzava koje podrzava fortumo:";
$jezik['upustvo'] 			= "Upustvo za SMS uplatu!";
$jezik['primer']			= "Beispiel:";
$jezik['info'] 				= "Info:";
$jezik['drzava'] 			= "Land:";
$jezik['pare'] 				= "Preis:";
$jezik['kod'] 				= "Kod:";
$jezik['send']				= "Senden an:";
$jezik['supp']				= "Unterst�tzung:";
$jezik['Pocetna']			= "Start Seite";
$jezik['Game Panel']		= "Game Panel";
$jezik['Korisnicki Panel']		= "Benutzer";
$jezik['Naruci']			= "Kaufen";
$jezik['Cenovnik']			= "Preis Liste";
$jezik['Kontakt']			= "Kontakt";
$jezik['GameTracker']		= "GameTracker";
$jezik['VESTI']				= "NACHRICHTEN";
$jezik['DEMO']				= "DEMO";
$jezik['LOGIN']				= "LOGIN";
$jezik['REGISTRUJ SE']		= "REGISTRIEREN";
$jezik['MOJ PROFIL']		= "MEIN PROFIL";
$jezik['EDIT']				= "EDIT";
$jezik['BILLING']			= "BILLING";
$jezik['LOGOUT']			= "LOGOUT";
$jezik['PREUZMITE NAJBOLJI COUNTER STRIKE 1.6']	= "COUNTER STRIKE 1.6 HERUNTERLADEN";
$jezik['DOWNLOAD NOW!']		= "HERUNTERLADEN!";
$jezik['Igra:']				= "Spiel:";
$jezik['USKORO!']			= "BALD!";
$jezik['Vise Info']			= "Mehr Info";
$jezik['Cena']			= "Preis per Slot";
?>