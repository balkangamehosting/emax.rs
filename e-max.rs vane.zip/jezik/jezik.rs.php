<?php 

/* 
------------------
Language: Serbian
------------------
*/

$jezik = array(); 

$jezik['1'] = "Cao :D";

$jezik['uplata'] 			= "Kako uplatiti pomoću SMS-a?";
$jezik['obv1'] 				= "1). Pitanja i sugestije vezane za SMS Servis pišite na: <span style='color:red;'>info@e-game.me</span>.";
$jezik['obv2'] 				= "2). SMS naplatu obezbijedio Fortumo.com.";
$jezik['obv3'] 				= "3). Izaberite državu iz koje šaljete SMS poruku.";
$jezik['obv4'] 				= "4). <span style='color:red;'>NAPOMENA!</span> Posle slanja SMS-a, može se desiti nekad da novac ne legne na vas nalog i po nekoliko sati zbog zakašnjenja između Fortuma i mobilnih provajdera! 
<br /> - U slučaju da vaš zatekne ovo, javite se na email: info@e-game.me ili blejab@gmail.com.!";
$jezik['drzave'] 			= "Lista drzava koje podrzava fortumo:";
$jezik['upustvo'] 			= "Upustvo za SMS uplatu!";
$jezik['primer']			= "Primer:";
$jezik['info'] 				= "Info:";
$jezik['drzava'] 			= "Drzava:";
$jezik['pare'] 				= "Cena:";
$jezik['kod'] 				= "Kod:";
$jezik['send']				= "Posalji na:";
$jezik['supp']				= "Podrska:";
$jezik[' Pocetna']			= " Početna";
$jezik[' Game Panel']		= " Game Panel";
$jezik[' Korisnicki Panel']		= " Korisnicki Panel";
$jezik[' Naruci']			= " Naruči";
$jezik[' Cenovnik']			= " Cenovnik";
$jezik[' Kontakt']			= " Kontakt";
$jezik['GameTracker']		= "GameTracker";
$jezik['VESTI']				= "VESTI";
$jezik['DEMO']				= "DEMO";
$jezik['LOGIN']				= "LOGIN";
$jezik[' REGISTRUJ SE']		= " REGISTRUJ SE";
$jezik[' MOJ PROFIL']		= " MOJ PROFIL";
$jezik['EDIT']				= "EDIT";
$jezik['BILLING']			= "BILLING";
$jezik['LOGOUT']			= "LOGOUT";
$jezik['PREUZMITE NAJBOLJI COUNTER STRIKE 1.6']	= "PREUZMITE NAJBOLJI COUNTER STRIKE 1.6";
$jezik['DOWNLOAD NOW!']		= "PREUZMITE SADA!";
$jezik['Igra:']				= "Igra:";
$jezik['USKORO!']			= "USKORO!";
$jezik['Vise Info']			= "Vise Info";
?>